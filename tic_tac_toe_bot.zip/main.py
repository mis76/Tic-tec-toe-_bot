from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, CallbackQueryHandler, MessageHandler, Filters, CallbackContext
import random
import os

TOKEN = os.getenv("TOKEN", "PASTE-YOUR-TOKEN-HERE")
ADMIN_ID = 6046871613

games = {}
pending_games = {}
random_waiting = None

def start(update: Update, context: CallbackContext):
    update.message.reply_text(
        "Welcome to Jafar Tic-Tac-Toe!\n\n"
        "/play_bot - Play against bot\n"
        "/play_friend - Create code for friend\n"
        "/join1234 - Join friend's game (replace 1234)\n"
        "/random_play - Play with a random player\n\n"
        "During game, you can chat by simply sending messages!"
    )

def create_board(board):
    keyboard = []
    for i in range(0, 9, 3):
        row = []
        for j in range(3):
            text = board[i+j] if board[i+j] != ' ' else str(i+j+1)
            row.append(InlineKeyboardButton(text, callback_data=str(i+j)))
        keyboard.append(row)
    return InlineKeyboardMarkup(keyboard)

def play_bot(update: Update, context: CallbackContext):
    chat_id = update.effective_chat.id
    board = [' '] * 9
    games[chat_id] = {'board': board, 'turn': '⭕', 'mode': 'bot'}
    update.message.reply_text('You vs Bot!\nYou are ⭕.', reply_markup=create_board(board))

def play_friend(update: Update, context: CallbackContext):
    chat_id = update.effective_chat.id
    code = str(random.randint(1000, 9999))
    pending_games[code] = chat_id
    update.message.reply_text(
        f"Send this code to your friend: /join{code}\nWaiting for your friend..."
    )

def join(update: Update, context: CallbackContext):
    chat_id = update.effective_chat.id
    code = update.message.text[5:]

    if code not in pending_games:
        update.message.reply_text("Invalid code!")
        return

    player1 = pending_games.pop(code)
    board = [' '] * 9
    games[player1] = {'board': board, 'turn': '⭕', 'mode': 'friend', 'opponent': chat_id}
    games[chat_id] = {'board': board, 'turn': '❌', 'mode': 'friend', 'opponent': player1}

    context.bot.send_message(player1, "Your friend joined! You are ⭕.")
    update.message.reply_text("Joined successfully! You are ❌.")

    context.bot.send_message(player1, "⭕ Your turn:", reply_markup=create_board(board))
    context.bot.send_message(chat_id, "Waiting for ⭕ to play...")

def random_play(update: Update, context: CallbackContext):
    global random_waiting
    chat_id = update.effective_chat.id

    if random_waiting and random_waiting != chat_id:
        opponent = random_waiting
        random_waiting = None
        board = [' '] * 9
        games[chat_id] = {'board': board, 'turn': '❌', 'mode': 'friend', 'opponent': opponent}
        games[opponent] = {'board': board, 'turn': '⭕', 'mode': 'friend', 'opponent': chat_id}

        context.bot.send_message(opponent, "Random player found! You are ⭕.")
        context.bot.send_message(chat_id, "Random player found! You are ❌.")

        context.bot.send_message(opponent, "⭕ Your turn:", reply_markup=create_board(board))
        context.bot.send_message(chat_id, "Waiting for ⭕ to play...")

    else:
        random_waiting = chat_id
        update.message.reply_text("Searching for random player... Please wait.")

def button(update: Update, context: CallbackContext):
    query = update.callback_query
    chat_id = query.message.chat.id
    query.answer()

    if chat_id not in games:
        query.edit_message_text(text="Game not found. Start again.")
        return

    game = games[chat_id]
    board = game['board']
    turn = game['turn']
    mode = game['mode']
    move = int(query.data)

    if board[move] != ' ':
        query.answer("Already taken!")
        return

    board[move] = turn
    winner = check_winner(board)

    if winner:
        win_text = f"{winner} Wins! 🏆🎉"
        send_result(chat_id, win_text)
        send_result(game.get('opponent'), win_text)
        games.pop(chat_id, None)
        if 'opponent' in game:
            games.pop(game['opponent'], None)
        return

    if ' ' not in board:
        draw_text = "It's a Draw 😢"
        send_result(chat_id, draw_text)
        send_result(game.get('opponent'), draw_text)
        games.pop(chat_id, None)
        if 'opponent' in game:
            games.pop(game['opponent'], None)
        return

    if mode == 'bot':
        if turn == '⭕':
            game['turn'] = '❌'
            bot_move = bot_play(board)
            board[bot_move] = '❌'
            winner = check_winner(board)
            if winner:
                query.edit_message_text(f"Bot {winner} wins! 🏆🎉\n/start to play again.")
                games.pop(chat_id, None)
                return
            if ' ' not in board:
                query.edit_message_text("It's a Draw 😢\n/start to play again.")
                games.pop(chat_id, None)
                return
            game['turn'] = '⭕'
            query.edit_message_reply_markup(reply_markup=create_board(board))
        return

    opponent_id = game.get('opponent')
    next_turn = '❌' if turn == '⭕' else '⭕'
    games[chat_id]['turn'] = next_turn
    games[opponent_id]['turn'] = next_turn

    context.bot.send_message(opponent_id, f"{next_turn} Your turn:", reply_markup=create_board(board))
    query.edit_message_text("Move sent. Waiting for opponent to play...")

def send_result(chat_id, text):
    if chat_id:
        try:
            updater.bot.send_message(chat_id, text)
        except Exception as e:
            print(f"Failed to send message to {chat_id}: {e}")

def check_winner(board):
    lines = [
        (0,1,2), (3,4,5), (6,7,8),
        (0,3,6), (1,4,7), (2,5,8),
        (0,4,8), (2,4,6)
    ]
    for a, b, c in lines:
        if board[a] == board[b] == board[c] and board[a] != ' ':
            return board[a]
    return None

def bot_play(board):
    empty = [i for i, v in enumerate(board) if v == ' ']
    return random.choice(empty)

updater = Updater(TOKEN, use_context=True)
dp = updater.dispatcher

dp.add_handler(CommandHandler("start", start))
dp.add_handler(CommandHandler("play_bot", play_bot))
dp.add_handler(CommandHandler("play_friend", play_friend))
dp.add_handler(CommandHandler("random_play", random_play))
dp.add_handler(MessageHandler(Filters.regex(r"^/join\d{4}$"), join))
dp.add_handler(CallbackQueryHandler(button))

updater.start_polling()
updater.idle()
